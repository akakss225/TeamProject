package com.howmuch.domain;

import lombok.Data;

@Data
public class CalculatorVO {
	
	private int min;
	private int max;
	private double avg;
	
}
