package com.howmuch.domain;

import lombok.Data;

@Data
public class Rank2VO {
	private String nick;
	
	private String tier;
	
	private int point;
	
}
