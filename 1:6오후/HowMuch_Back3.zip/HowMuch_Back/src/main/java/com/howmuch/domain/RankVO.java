package com.howmuch.domain;

import lombok.Data;

@Data
public class RankVO {
	private String nick;
	private int score;
	private int posting;
	
}
