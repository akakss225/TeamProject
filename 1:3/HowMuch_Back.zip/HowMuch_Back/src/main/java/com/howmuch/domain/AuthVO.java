package com.howmuch.domain;

import lombok.Data;

@Data
public class AuthVO {
	private String email;
	private String authority;
}
