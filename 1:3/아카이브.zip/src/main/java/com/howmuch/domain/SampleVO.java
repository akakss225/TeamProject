package com.howmuch.domain;

import lombok.Data;

@Data
public class SampleVO {
	private int id;
	private String name;
	private int age;
}
